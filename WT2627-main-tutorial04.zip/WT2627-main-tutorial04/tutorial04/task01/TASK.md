## Task 01 | Two PHP Vulnerabilities

PHP fixed two vulnerabilities in its core on 21.10.2026 ([CVE-2026-109618](https://github.com/php/php-src/security/advisories/GHSA-w8hw-w9fx-j79w), [CVE-2026-109619](https://github.com/php/php-src/security/advisories/GHSA-6wmf-4rv5-p3rp)).

**Research both vulnerabilities and present in the next tutorial how an attacker exploits them.**

1. What goes wrong inside PHP in each case?
2. What does an attacker need: which requests, which server setup, which privileges?
3. What does the attacker gain?
4. Which PHP installations are affected, and what protects one that cannot update?

### Reflect

- Both advisories rate the attack complexity as high. What makes the attack hard, and does that change how fast you update?
