## Task 03 | Do We Ship the Outdated PHP?

The PHP advisory (CVE-2026-109618, CVE-2026-109619) also reaches the university's IT department, which runs three more products with PHP inside:

- phpMyAdmin 5.2.2: web interface of the database servers
- Matomo 5.14.0: web analytics of the faculty website
- Booking portal of a supplier, who delivered only the SBOM of its image

`compose.yaml` declares the two images, `ubuntu-22.04-php.cdx.json` is the supplier's SBOM.

**Decide for every product whether it ships the outdated PHP**, and back each answer with the lines of your syft and grype output that show it.

### Reflect

- How can PHP get into an image without appearing in a syft SBOM?
