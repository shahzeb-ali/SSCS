# PHP Check: Do Our Images Ship the Outdated PHP?

The PHP advisory of 21.10.2026 (CVE-2026-109618, CVE-2026-109619, remote code execution in the PHP core) names the fixed versions 8.2.35, 8.3.36, 8.4.27 and 8.5.12 ([GHSA-w8hw-w9fx-j79w](https://github.com/php/php-src/security/advisories/GHSA-w8hw-w9fx-j79w), [GHSA-6wmf-4rv5-p3rp](https://github.com/php/php-src/security/advisories/GHSA-6wmf-4rv5-p3rp)). syft writes an SBOM for each of four images, grype matches each SBOM against its vulnerability records, and a VEX statement removes a finding that does not apply to the WordPress image.

Run date: 2026-11-11, about 17:55 to 18:15 UTC, in the Tutorial 05 dev container with the Docker socket mounted.

## Images

| Image | PHP | Digest |
|---|---|---|
| `php:8.3.35-apache` | 8.3.35, compiled from source into `/usr/local` | `sha256:c59c808172ee3672cd334f8f2a5d7b1480a9d7273a368f412b8ee9b4ef418184` |
| `php:8.3.36-apache` | 8.3.36, same build | `sha256:a800bbd2c0aa322702259ed475556b2cbc311076a8d3c4bba9bfe96838745472` |
| `sscs-ubuntu-php:24.04` | Ubuntu's `php8.3` 8.3.6-0ubuntu0.24.04.13 from apt (`ubuntu-php/Dockerfile`) | built locally |
| `wordpress:6.9-php8.3-apache` | 8.3.31, built `FROM php:8.3-apache`, tag unchanged since 2026-05-20 | `sha256:5d2c212561c4b5442ebc4d98933a9cbadcf3dee8888ed3fd9ed44667c27cc905` |

## Results

**Inventory** (`results/syft-*.txt`): syft finds the PHP compiled from source by reading the binaries and lists two entries of type `binary`: `php-cli` (`/usr/local/bin/php`) and `libphp` (the Apache module), each with CPE `cpe:2.3:a:php:php:<version>`. In the Ubuntu image the same files belong to deb packages, and syft lists only the packages (`php8.3-cli`, `php8.3-common`, `libapache2-mod-php8.3`, ...).

**Match** (`results/grype-*.txt`, `results/advisory-rows.txt`): rows for CVE-2026-109618 and CVE-2026-109619.

| Image | Rows | Why |
|---|---|---|
| `php:8.3.35-apache` | 4 | both CVEs for `php-cli` and `libphp`, fixed in 8.3.36 |
| `php:8.3.36-apache` | 0 | fixed version |
| `sscs-ubuntu-php:24.04` | 0 | grype matches the deb packages against Ubuntu's records: USN-8948-1 fixed both CVEs in `8.3.6-0ubuntu0.24.04.13`, under the old upstream version 8.3.6 |
| `wordpress:6.9-php8.3-apache` | 4 | PHP 8.3.31, plus 14 older PHP CVEs fixed in 8.3.32 to 8.3.35 |

The binaries are matched by CPE against NVD, the deb packages by package name and full package version against the Ubuntu feed.

**Verdict with VEX** (`wordpress.vex.json`, `results/wordpress-*.txt`): among the WordPress findings, CVE-2026-17545 (reserved device names such as `CON` and `NUL` reach `CreateFileW()`) affects only PHP on Windows: the advisory says "Only Windows deployments are affected" ([GHSA-9f67-6fw4-hpfp](https://github.com/php/php-src/security/advisories/GHSA-9f67-6fw4-hpfp)), and the fix touches only `win32/` and code under `#ifdef ZEND_WIN32`. Debian and Ubuntu mark it not affected or ignored for their PHP packages ("Only affects PHP on Windows"); grype shows Ubuntu's decision as `(won't fix)` in `results/grype-ubuntu.txt`. The statement: product = the WordPress image by digest, subcomponents `pkg:generic/php-cli` and `pkg:generic/php` (versionless), `not_affected`, `vulnerable_code_not_present`.

| Scan of the WordPress image | PHP rows |
|---|---|
| without VEX | 32 |
| with VEX | 30, CVE-2026-17545 gone; the advisory CVEs stay |
| with VEX, `--show-suppressed` | 32, CVE-2026-17545 marked `(suppressed by VEX)` |
| CycloneDX SBOM with VEX | 32: the SBOM file carries no image digest, so the product of the statement does not match |

grype matches the product only when it scans the image itself (from the Docker daemon or from the registry); it reads no image digest from a CycloneDX SBOM ([grype #3476](https://github.com/anchore/grype/issues/3476)).

## Environment

- Tutorial 05 dev container (`tutorial05/.devcontainer/`), aarch64, Docker Engine 29.8.2 linux/arm64; images scanned as linux/arm64.
- syft 1.56.0, grype 0.121.1, grype database v6.1.10 built 2026-11-11T06:21:32Z (`results/versions.txt`).
- `build/` (gitignored): SBOMs (CycloneDX JSON, 1.6 to 3.5 MB each), full syft and grype tables, grype JSON.

## Commands

On the host, build the Ubuntu image:

```sh
docker build -t sscs-ubuntu-php:24.04 ubuntu-php/
```

In the dev container (Docker socket mounted), from this folder:

```sh
./collect.sh
```

The steps of `collect.sh` for one image, run in `build/` (file names: `outdated`, `fixed`, `ubuntu`, `wordpress`):

```sh
syft php:8.3.35-apache -o table -o cyclonedx-json=outdated.json
grype sbom:outdated.json
grype wordpress:6.9-php8.3-apache --vex wordpress.vex.json --show-suppressed
```

For a reproducible rerun with the database of the run date: `GRYPE_DB_AUTO_UPDATE=false` and `grype db import` with the URL in `results/versions.txt`.

## Supplier SBOM of Task 03

`task03/ubuntu-22.04-php.cdx.json` was made with `docker build --build-arg UBUNTU=22.04@sha256:076e7bf82319619f28dd0aa9c02ab34b055ad37100395b4f49a2ffba04fb5e11 --build-arg PHP=8.1 -t sscs-ubuntu-php:22.04 examples/php-check/ubuntu-php/`, then `syft sscs-ubuntu-php:22.04 --source-name booking-portal --source-version 2.4.0 -o cyclonedx-json=task03/ubuntu-22.04-php.cdx.json`.
