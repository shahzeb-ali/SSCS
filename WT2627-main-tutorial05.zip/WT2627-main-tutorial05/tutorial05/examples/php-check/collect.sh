#!/bin/sh
# PHP check of the tutorial: SBOM per image with syft, matching with grype,
# rescan of the WordPress image with a VEX statement. Runs in the Tutorial 05
# dev container with the Docker socket mounted; the Ubuntu image is built on
# the host first (README). The commands run in build/ exactly as the slides
# show them; full outputs stay in build/, the lines with PHP go to results/.
set -eu
cd "$(dirname "$0")"
mkdir -p build results
R=../results
cp wordpress.vex.json build/

{ syft version; echo; grype version; echo; grype db status; } > results/versions.txt

# rows of a syft or grype table: header plus the rows of PHP packages
php_rows() { grep -E '^(NAME|libphp|php|libapache2-mod-php)' || true; }

cd build
# inventory: one SBOM per image (images pinned by the digests in the README)
syft php:8.3.35-apache -o table=syft-outdated.txt -o cyclonedx-json=outdated.json
syft php:8.3.36-apache -o table=syft-fixed.txt -o cyclonedx-json=fixed.json
syft sscs-ubuntu-php:24.04 -o table=syft-ubuntu.txt -o cyclonedx-json=ubuntu.json
syft wordpress:6.9-php8.3-apache -o table=syft-wordpress.txt -o cyclonedx-json=wordpress.json
# the WordPress image's entries for WordPress and PHP: a plugin and the PHP binaries
grep -E 'wordpress|libphp|php-cli' syft-wordpress.txt > "$R/syft-wordpress-entries.txt"

# match: the stored SBOMs against the vulnerability records
for n in outdated fixed ubuntu wordpress; do
  php_rows < "syft-$n.txt" > "$R/syft-$n.txt"
  grype "sbom:$n.json" -o table="grype-$n.txt" -o json="grype-$n.json"
  php_rows < "grype-$n.txt" > "$R/grype-$n.txt"
  echo "$n: $(grep -cE 'CVE-2026-10961[89]' "grype-$n.txt" || true) rows"
done > "$R/advisory-rows.txt"

# verdict: grype scans the image itself, so that the VEX product (the image
# digest) matches; without and with the statement
grype wordpress:6.9-php8.3-apache -o table=wordpress-without-vex.txt
grype wordpress:6.9-php8.3-apache --vex wordpress.vex.json -o table=wordpress-with-vex.txt
grype wordpress:6.9-php8.3-apache --vex wordpress.vex.json --show-suppressed -o table=wordpress-with-vex-suppressed.txt
for f in without-vex with-vex with-vex-suppressed; do
  php_rows < "wordpress-$f.txt" > "$R/wordpress-$f.txt"
done
# the same statement on the CycloneDX SBOM: the image digest is not in it
grype sbom:wordpress.json --vex wordpress.vex.json -o table=wordpress-sbom-with-vex.txt
php_rows < wordpress-sbom-with-vex.txt > "$R/wordpress-sbom-with-vex.txt"
