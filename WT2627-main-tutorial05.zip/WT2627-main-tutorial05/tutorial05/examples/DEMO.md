# Tutorial 05: Live Demo

Commands in the order of the slides. Open `tutorial05/` in VS Code, *Reopen in Container*, then a terminal. The dev container image holds the grype database of the day it was built. The first run pulls the images and Bazel's downloads.

```bash
T=$PWD                              # the terminal opens in tutorial05/
grype db update                     # newest vulnerability database, a few minutes on first use
grype db status                     # build date, status valid
```

## Part 1: Outdated PHP in Our Images

```bash
cd $T/examples/php-check/build
```

### syft | SBOM per Image

```bash
syft php:8.3.35-apache                                              # reads the image layer by layer
syft php:8.3.35-apache -o table -o cyclonedx-json=outdated.json | grep php
jq '.components[] | select(.name=="php-cli")' outdated.json        # CPE, PURL, path /usr/local/bin/php
syft php:8.3.36-apache -o cyclonedx-json=fixed.json
```

### grype | Match an SBOM

```bash
grype sbom:outdated.json                          # about 1,160 findings, nearly all in Debian packages
grype sbom:outdated.json | grep CVE-2026-10961    # the two CVEs of the advisory, fixed in 8.3.36
grype sbom:fixed.json | grep CVE-2026-10961       # no output
grype sbom:outdated.json -o json | grype explain --id CVE-2026-109618   # why: CPE match against NVD
```

### Ubuntu | Backported Fix

```bash
syft sscs-ubuntu-php:24.04 -o table -o cyclonedx-json=ubuntu.json | grep php8.3-cli
grype sbom:ubuntu.json | grep CVE-2026-10961      # no output
grype db search --vuln CVE-2026-109618 --pkg php8.3   # Ubuntu's record: < 8.3.6-0ubuntu0.24.04.13
```

### Verdict | VEX and Rescan

```bash
syft wordpress:6.9-php8.3-apache | grep -E "libphp|php-cli"   # image 3: our website, official WordPress image on PHP 8.3.31
grype wordpress:6.9-php8.3-apache | grep -E "10961|17545"   # CVE-2026-17545: only PHP on Windows
cat > wordpress.vex.json <<'EOF'
{
  "@context": "https://openvex.dev/ns/v0.2.0",
  "@id": "https://hbrs.example/sscs/vex/wordpress-6.9-php8.3-apache-2026-11-11",
  "author": "SSCS tutorial example",
  "timestamp": "2026-11-11T18:00:00Z",
  "version": 1,
  "statements": [
    {
      "vulnerability": {
        "name": "CVE-2026-17545"
      },
      "products": [
        {
          "@id": "pkg:oci/wordpress@sha256%3A5d2c212561c4b5442ebc4d98933a9cbadcf3dee8888ed3fd9ed44667c27cc905?repository_url=index.docker.io%2Flibrary%2Fwordpress",
          "subcomponents": [
            {
              "@id": "pkg:generic/php-cli"
            },
            {
              "@id": "pkg:generic/php"
            }
          ]
        }
      ],
      "status": "not_affected",
      "justification": "vulnerable_code_not_present",
      "impact_statement": "CVE-2026-17545 concerns reserved device names on Windows (CON, NUL, COM1 ...). The image runs PHP built for Linux."
    }
  ]
}
EOF
grype wordpress:6.9-php8.3-apache --vex wordpress.vex.json --show-suppressed | grep -E "10961|17545"
```

## Part 2: Bazel 101

```bash
cd $T/examples/version-check
B=(--noshow_progress --ui_event_filters=-info,-warning)   # quiet bazel output (zsh array)
```

### Example and Project Layout

```bash
ls -a . java/versioncheck native python
cat MODULE.bazel
```

### Targets, Build and Test

```bash
cat native/BUILD.bazel
bazel build //native:version
bazel test //native:version_test
```

### Only Declared Inputs

```bash
cp native/BUILD.bazel /tmp/BUILD.bazel.orig
sed -i '/":compare",/d' native/BUILD.bazel        # remove :compare from the deps of range
bazel build $B //native:range                     # compare.h: No such file or directory
cp /tmp/BUILD.bazel.orig native/BUILD.bazel       # restore
```

### Time and Environment

```bash
bazel aquery 'mnemonic("CppCompile", //native:range)' 2>/dev/null | grep -E "Environment|__DATE__|__TIME"
```

### Incremental Build and Build Graph

```bash
cp native/range.c /tmp/range.c.orig
sed -i 's/caret_allows(&v, &base) : 1;/caret_allows(\&v, \&base) != 0 : 1;/' native/range.c
bazel build -s //native:range 2>&1 | grep -oE "'(Compiling|Linking)[^']*'"   # only range is rebuilt
cp /tmp/range.c.orig native/range.c               # restore
bazel query 'filter("^//", deps(//native:range))' --output graph
```

### Across Languages and Run

```bash
cat java/versioncheck/BUILD.bazel
bazel run $B //java/versioncheck:check -- 8.3.35 ">=8.3.36"
cat python/BUILD.bazel
bazel run $B //python:check -- 8.3.35 ">=8.3.36"
```

### C Toolchain | Compiler of the Machine

```bash
bazel build $B //native:versioncheck
readelf -p .comment bazel-bin/native/libversioncheck.so            # GCC of the dev container
```

### C Toolchain | Declared Compiler

About 30 s on the first run: Bazel builds clang's runtime libraries once (downloads are cached).

```bash
grep -n llvm MODULE.bazel .bazelrc
bazel build $B --config=hermetic //native:versioncheck
readelf -p .comment bazel-bin/native/libversioncheck.so            # clang version 23.1.2
```

### Java and Python | Declared Runtime

```bash
cat .bazelrc
java -version                                     # machine: Temurin 25.0.5
bazel run $B //java/versioncheck:check -- 8.3.35 ">=8.3.36"    # Bazel: Azul Systems 25.0.4
python3 --version                                 # machine: Python 3.14.4
bazel run $B //python:check -- 8.3.35 ">=8.3.36"  # Bazel: CPython 3.14.3
```

## If something fails

The recorded outputs are in `php-check/results/` and `version-check/results/`; `php-check/collect.sh` reruns the whole PHP part.
