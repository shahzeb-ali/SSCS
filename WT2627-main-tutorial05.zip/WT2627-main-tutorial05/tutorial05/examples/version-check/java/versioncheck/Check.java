package versioncheck;

import com.github.fmeum.rules_jni.RulesJni;

/** Checks a version against a range with the C function range_satisfies. */
public class Check {

  static {
    // unpacks the JNI library from the jar and loads it
    RulesJni.loadLibrary("versioncheck_jni", Check.class);
  }

  // implemented in check_jni.c, which calls range_satisfies of native/range.h
  private static native int rangeSatisfies(String version, String range);

  public static void main(String[] args) {
    int res = rangeSatisfies(args[0], args[1]);

    String verdict = switch (res) {
      case 1 -> "yes";
      case 0 -> "no";
      default -> "parse error";
    };
    System.out.printf("%s satisfies %s: %s%n", args[0], args[1], verdict);
    System.out.printf("Java runtime: %s %s%n",
      System.getProperty("java.vendor"), System.getProperty("java.version"));
  }
}
