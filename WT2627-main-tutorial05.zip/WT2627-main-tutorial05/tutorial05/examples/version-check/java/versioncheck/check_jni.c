#include "native/range.h"
#include "versioncheck_Check.h"

/*
 * C side of the Java method Check.rangeSatisfies: turns the two Java strings
 * into C strings and calls range_satisfies. Returns -1 if a string is missing.
 */
JNIEXPORT jint JNICALL Java_versioncheck_Check_rangeSatisfies(
    JNIEnv *env, jclass clazz, jstring version, jstring range) {
  (void)clazz;
  if (version == NULL || range == NULL) {
    return -1;
  }
  const char *v = (*env)->GetStringUTFChars(env, version, NULL);
  const char *r = (*env)->GetStringUTFChars(env, range, NULL);
  jint result = -1;
  if (v != NULL && r != NULL) {
    result = range_satisfies(v, r);
  }
  if (v != NULL) {
    (*env)->ReleaseStringUTFChars(env, version, v);
  }
  if (r != NULL) {
    (*env)->ReleaseStringUTFChars(env, range, r);
  }
  return result;
}
