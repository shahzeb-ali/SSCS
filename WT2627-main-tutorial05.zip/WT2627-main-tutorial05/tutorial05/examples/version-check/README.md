# Version Check: C Library, Java Program, Python Script, Bazel

`native/` holds a small C library in three modules: `version` parses `MAJOR.MINOR.PATCH`, `compare` orders two versions, `range` checks a version against a range `>=X.Y.Z` or `^X.Y.Z`. `native/version_test.c` tests the parser. `java/versioncheck/Check.java` calls `range_satisfies` through the Java Native Interface (JNI): `check_jni.c` is the C side, built with [rules_jni](https://github.com/fmeum/rules_jni) into a JNI library that depends on `//native:range` and travels inside the jar. `python/check.py` calls the function through Python's `ctypes`. Both print the runtime they run on. Bazel builds all three, with the Python interpreter declared in `MODULE.bazel` (aspect_rules_py 1.13.0, Python 3.14) and the JDK in `.bazelrc`.

Inside the Tutorial 05 dev container:

```bash
cd tutorial05/examples/version-check
bazel test //native:version_test
bazel run //java/versioncheck:check -- 8.3.35 ">=8.3.36"
bazel run //python:check -- 8.3.35 ">=8.3.36"
bazel query "filter(\"^//\", deps(//java/versioncheck:check))" --output graph
bazel aquery 'mnemonic("CppCompile", //native:range)'
readelf -p .comment bazel-bin/native/libversioncheck.so
bazel build --config=hermetic //native:versioncheck
readelf -p .comment bazel-bin/native/libversioncheck.so
```

The C toolchain has two variants. The default build takes the compiler found on the machine. `bazel build --config=hermetic //native:versioncheck` takes clang and lld from the module `llvm` (hermetic-llvm), declared in `MODULE.bazel`; `.bazelrc` defines the config.

`naive/` builds the C sources with a Makefile and its own `Check.java` with Maven; that `Check.java` calls the library through Java's Foreign Function and Memory API: `cd naive && ./run.sh 3.53.4 ">=3.53.0"`.

## Results

Run on 2026-11-04 on aarch64 with Bazel 9.3.1, runs from 2026-11-15 with Bazel 9.3.2 (bazelisk 1.30.0), rules_cc 0.2.27, rules_java 9.9.0, hermetic-llvm (`llvm`) 0.8.26. Error lines are shortened to the lines that name the cause.

| File | Machine | Content |
|---|---|---|
| `sqlite-jdbc-native.txt` | A | native libraries in `sqlite-jdbc` 3.53.4.0 and the compiler recorded in the Linux aarch64 build |
| `naive-machine-a.txt`, `naive-machine-b.txt` | A, B | `naive/run.sh`: compiler, SHA-256 of the library, JDK |
| `tree.txt`, `tree-bazel-files.txt` | A | files of the workspace, and its Bazel files only (run 2026-11-15) |
| `ls-native.txt` | A | files of the package `native` (run 2026-11-12) |
| `bazel-run.txt`, `query-graph.txt` | A | run and build graph of `//java/versioncheck:check` (run 2026-11-15) |
| `build-native.txt` | A | actions of `bazel build -s //native:versioncheck` after `bazel clean` |
| `clean-build-actions.txt` | A | action count of a build after `bazel clean`, machine compiler and hermetic-llvm |
| `rebuild-range.txt`, `rebuild-java.txt` | A | actions after a change to `range.c` and to `Check.java` |
| `missing-deps.txt` | A | `:compare` removed from the deps of `range` |
| `java-runtime-21.txt` | A | `--java_runtime_version=remotejdk_21` |
| `host-gcc-machine-a.txt`, `host-gcc-machine-b.txt` | A, B | auto-configured toolchain |
| `hermetic-machine-a.txt`, `hermetic-machine-b.txt` | A, B | hermetic-llvm |
| `hermetic-clang-download.txt`, `remotejdk-download.txt` | A | `bazel mod show_repo` of the clang archive and of the JDK 25 archive |
| `toolchains-llvm-libxml2.txt` | A | `toolchains_llvm` 1.13.0 with LLVM 22.1.8 instead of hermetic-llvm |
| `amd64.txt` | A (amd64) | auto-configured and hermetic toolchain on `linux/amd64` under emulation |
| `bazel-test.txt` | A | build of `//native:version` and its test, after `bazel clean` (run 2026-11-11) |
| `query-graph-range.txt` | A | build graph of `//native:range` (run 2026-11-11) |
| `host-gcc-machine-b-range.txt` | B | `bazel build //native:range` with the auto-configured toolchain: the link needs `libstdc++`, which B lacks (gcc without g++) (run 2026-11-11) |
| `missing-deps-range.txt` | A | `:compare` removed from the deps of `range`, build of `//native:range` (run 2026-11-11) |
| `rebuild-range-library.txt` | A | actions of `bazel build -s //native:range` after a change to `range.c` (run 2026-11-11) |
| `java-runtime-php.txt`, `python-runtime-php.txt` | A | JDK and Python of the machine, then the Java and the Python program on the PHP versions of Tutorial 05, each printing the runtime Bazel starts it on (run 2026-11-12) |
| `query-graph-programs.txt` | A | build graph of `//java/versioncheck:check` and `//python:check` (run 2026-11-15) |
| `rebuild-range-programs.txt` | A | actions of `bazel build -s //java:check //python:check` after a change to `range.c`: the C library is built once per program configuration (run 2026-11-12) |
| `jre-machine-a.txt` | A | JDK of the machine (`java -version`) and the runtime `bazel run` starts the program on (run 2026-11-15) |
| `javac-jdk.txt` | A | JDK that runs `javac` for `//java/versioncheck:check` and the language level it gets (run 2026-11-15) |
| `default-toolchain.txt`, `hermetic-config.txt` | A | `//native:versioncheck` with the default toolchain and with `--config=hermetic`: compiler recorded in the library and its SHA-256 (run 2026-11-15, Bazel 9.3.2) |
| `action-date-env.txt` | A | environment and date macros of the compile action of `range.c` (run 2026-11-15) |
| `deploy-jar.txt` | A | deploy jar of the Java program: the JNI library inside the jar, and a run with the JDK of the machine (run 2026-11-15) |

- Machine A: the Tutorial 05 dev container image (Ubuntu, gcc 15.2.0, Temurin 25).
- `hermetic-machine-b.txt` records a second build in B's own cache volume; the first build there ran 1400 actions.
- Machine B: `debian:13` (`sha256:2dc419c6d7fe3dad0a2f9fd469c34cc90b0f9ba642d8fde837fe3d7d34a0e7f1`) with `gcc libc6-dev make maven default-jdk-headless binutils curl ca-certificates` from apt, bazelisk 1.30.0 checked against its SHA-256.
- The Java program uses JNI with rules_jni and the target `//java/versioncheck:check`. `rebuild-java.txt`, `rebuild-range.txt`, `rebuild-range-programs.txt`, `java-runtime-21.txt`, `clean-build-actions.txt`, `build-native.txt`, `amd64.txt`, `toolchains-llvm-libxml2.txt`, `host-gcc-machine-*.txt` and `hermetic-machine-*.txt` were recorded with the earlier Java program (Foreign Function and Memory API, target `//java:check`, toolchain lines switched in `MODULE.bazel`); their C results still hold.
