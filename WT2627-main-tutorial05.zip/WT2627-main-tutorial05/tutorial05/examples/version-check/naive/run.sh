#!/bin/sh
# Builds both parts with the tools of the machine and runs the check.
set -eu
make
mvn -q package
java --enable-native-access=ALL-UNNAMED \
    -Dversioncheck.path=build/libversioncheck.so \
    -cp target/classes versioncheck.Check "$@"
