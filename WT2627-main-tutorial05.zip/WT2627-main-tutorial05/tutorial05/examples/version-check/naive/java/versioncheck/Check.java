package versioncheck;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.SymbolLookup;
import java.lang.invoke.MethodHandle;
import java.nio.file.Path;

/** Checks a version against a range with the C library libversioncheck. */
public class Check {

  public static void main(String[] args) throws Throwable {
    Path path = Path.of(System.getProperty("versioncheck.path"));

    try (Arena arena = Arena.ofConfined()) {
      // range.h: int range_satisfies(const char *version, const char *range)
      SymbolLookup lib = SymbolLookup.libraryLookup(path, arena);
      MethodHandle fn = Linker.nativeLinker().downcallHandle(
        lib.find("range_satisfies").orElseThrow(),
        FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS));
      int res = (int) fn.invokeExact(arena.allocateFrom(args[0]), arena.allocateFrom(args[1]));

      String verdict = switch (res) {
        case 1 -> "yes";
        case 0 -> "no";
        default -> "parse error";
      };
      System.out.printf("%s satisfies %s: %s%n", args[0], args[1], verdict);
      System.out.printf("Java runtime: %s %s%n",
        System.getProperty("java.vendor"), System.getProperty("java.version"));
    }
  }
}
