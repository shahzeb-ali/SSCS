#ifndef COMPARE_H
#define COMPARE_H

#include "version.h"

/* Negative if a < b, zero if equal, positive if a > b. */
int version_compare(const struct version *a, const struct version *b);

#endif
