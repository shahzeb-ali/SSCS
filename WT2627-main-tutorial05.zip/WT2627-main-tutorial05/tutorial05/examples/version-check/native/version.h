#ifndef VERSION_H
#define VERSION_H

struct version {
    long major;
    long minor;
    long patch;
};

/* Parses "MAJOR.MINOR.PATCH"; returns 0 on success, -1 otherwise. */
int version_parse(const char *text, struct version *out);

#endif
