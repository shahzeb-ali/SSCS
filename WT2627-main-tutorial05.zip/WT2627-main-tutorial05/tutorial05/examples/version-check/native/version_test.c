#include "version.h"

#include <stdio.h>

/* Exit code 0 tells Bazel the test passed, any other value that it failed. */
int main(void) {
    struct version v;
    int failures = 0;

    if (version_parse("3.53.4", &v) != 0 || v.major != 3 || v.minor != 53 || v.patch != 4) {
        printf("FAIL: 3.53.4\n");
        failures++;
    }
    if (version_parse("3.53", &v) != -1) {
        printf("FAIL: 3.53 must be rejected\n");
        failures++;
    }
    if (version_parse("3.x.4", &v) != -1) {
        printf("FAIL: 3.x.4 must be rejected\n");
        failures++;
    }
    printf("%s\n", failures == 0 ? "PASS" : "FAILED");
    return failures == 0 ? 0 : 1;
}
