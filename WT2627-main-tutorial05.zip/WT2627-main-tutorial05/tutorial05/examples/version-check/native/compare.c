#include "compare.h"

static int sign(long difference) {
    return (difference > 0) - (difference < 0);
}

int version_compare(const struct version *a, const struct version *b) {
    if (a->major != b->major) {
        return sign(a->major - b->major);
    }
    if (a->minor != b->minor) {
        return sign(a->minor - b->minor);
    }
    return sign(a->patch - b->patch);
}
