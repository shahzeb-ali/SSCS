#include "version.h"

#include <ctype.h>
#include <stdlib.h>

/* Reads one non-negative number and advances *text past it. */
static int read_number(const char **text, long *out) {
    char *end;

    if (!isdigit((unsigned char)**text)) {
        return -1;
    }
    *out = strtol(*text, &end, 10);
    *text = end;
    return 0;
}

int version_parse(const char *text, struct version *out) {
    if (read_number(&text, &out->major) != 0 || *text++ != '.') {
        return -1;
    }
    if (read_number(&text, &out->minor) != 0 || *text++ != '.') {
        return -1;
    }
    if (read_number(&text, &out->patch) != 0 || *text != '\0') {
        return -1;
    }
    return 0;
}
