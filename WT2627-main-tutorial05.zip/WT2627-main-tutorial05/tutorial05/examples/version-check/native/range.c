#include "range.h"

#include <string.h>

#include "compare.h"
#include "version.h"

static int caret_allows(const struct version *v, const struct version *base) {
    if (base->major != 0) {
        return v->major == base->major;
    }
    if (base->minor != 0) {
        return v->major == 0 && v->minor == base->minor;
    }
    return version_compare(v, base) == 0;
}

int range_satisfies(const char *version, const char *range) {
    struct version v;
    struct version base;
    int caret;

    if (strncmp(range, ">=", 2) == 0) {
        caret = 0;
        range += 2;
    } else if (range[0] == '^') {
        caret = 1;
        range += 1;
    } else {
        return -1;
    }
    if (version_parse(version, &v) != 0 || version_parse(range, &base) != 0) {
        return -1;
    }
    if (version_compare(&v, &base) < 0) {
        return 0;
    }
    return caret ? caret_allows(&v, &base) : 1;
}
