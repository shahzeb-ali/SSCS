#ifndef RANGE_H
#define RANGE_H

/*
 * Checks a version against a range ">=X.Y.Z" or "^X.Y.Z" (npm semantics:
 * at least X.Y.Z, same leftmost non-zero component).
 * Returns 1 if satisfied, 0 if not, -1 on a parse error.
 */
int range_satisfies(const char *version, const char *range);

#endif
