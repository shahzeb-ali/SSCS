"""Checks a version against a range with the C library libversioncheck."""

import ctypes
import platform
import sys
from pathlib import Path

# runfiles of the binary: python/check.py next to native/libversioncheck.so
LIBRARY = Path(__file__).parent.parent / "native" / "libversioncheck.so"
lib = ctypes.CDLL(str(LIBRARY))

# range.h: int range_satisfies(const char *version, const char *range)
lib.range_satisfies.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
lib.range_satisfies.restype = ctypes.c_int

version, spec = sys.argv[1], sys.argv[2]
result = lib.range_satisfies(version.encode(), spec.encode())
verdict = {1: "yes", 0: "no"}.get(result, "parse error")
print(f"{version} satisfies {spec}: {verdict}")
print(f"Python runtime: {platform.python_implementation()} {platform.python_version()}")
