#ifndef CHECKSUM_H
#define CHECKSUM_H

/* CRC-32 of a NUL-terminated string, computed by zlib. */
unsigned long checksum_crc32(const char *text);

/* Version string of the zlib the library was linked with. */
const char *checksum_zlib_version(void);

#endif
