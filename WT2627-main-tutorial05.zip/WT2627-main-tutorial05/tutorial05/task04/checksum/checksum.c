#include "checksum.h"

#include <string.h>
#include <zlib.h>

unsigned long checksum_crc32(const char *text) {
    return crc32(crc32(0L, Z_NULL, 0), (const Bytef *)text, (uInt)strlen(text));
}

const char *checksum_zlib_version(void) {
    return zlibVersion();
}
