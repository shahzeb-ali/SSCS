#include "checksum.h"

#include <stdio.h>

/* Checks one known CRC-32 value and prints which compiler and which zlib
   built this test. Exit code 0: passed. */
int main(void) {
    unsigned long crc = checksum_crc32("hello");

#if defined(__clang__)
    printf("compiler: clang %s\n", __clang_version__);
#elif defined(__GNUC__)
    printf("compiler: gcc %s\n", __VERSION__);
#endif
    printf("zlib: %s\n", checksum_zlib_version());
    printf("crc32(\"hello\") = %08lx\n", crc);
    return crc == 0x3610a686UL ? 0 : 1;
}
