cmake_minimum_required(VERSION 3.15)
project(checksum C)

find_package(ZLIB REQUIRED)

add_library(checksum checksum.c)
target_include_directories(checksum PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(checksum PUBLIC ZLIB::ZLIB)

enable_testing()
add_executable(checksum_test checksum_test.c)
target_link_libraries(checksum_test PRIVATE checksum)
add_test(NAME checksum_test COMMAND checksum_test)
