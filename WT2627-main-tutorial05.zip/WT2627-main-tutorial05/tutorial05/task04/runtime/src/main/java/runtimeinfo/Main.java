package runtimeinfo;

import java.io.DataInputStream;
import java.io.IOException;

/** Prints the Java runtime it runs on and the class file version javac wrote. */
public class Main {

  public static void main(String[] args) throws IOException {
    System.out.printf("runtime: %s %s%n",
      System.getProperty("java.vendor"), System.getProperty("java.version"));
    System.out.printf("java.home: %s%n", System.getProperty("java.home"));

    // class file header: magic (4 bytes), minor version (2), major version (2)
    try (DataInputStream in = new DataInputStream(
        Main.class.getResourceAsStream("Main.class"))) {
      in.readInt();
      in.readUnsignedShort();
      int major = in.readUnsignedShort();
      System.out.printf("class file version: %d (Java %d)%n", major, major - 44);
    }
  }
}
