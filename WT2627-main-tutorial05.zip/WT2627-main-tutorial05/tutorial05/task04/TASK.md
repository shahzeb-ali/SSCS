## Task 04 | Conan and Maven, then Bazel

`checksum/` is a C library that links zlib, `runtime/` a Java program.

**Build both with their own tools, then with Bazel.** **Compare where each build declares its inputs.**

1. Conan and CMake for `checksum/`: zlib 1.3.1 from [ConanCenter](https://conan.io/center/recipes/zlib). Maven for `runtime/`: Java language level 21.
2. Bazel for both in one module: `checksum` links the module [zlib](https://registry.bazel.build/modules/zlib) 1.3.1, Java language level 21, hermetic C compiler and JRE in every build. `tutorial05/examples/version-check` shows how to declare them.
3. Per build: which file or machine decides the zlib version, the hash of the zlib download, the C compiler, the Java language level, the compiling JDK and the Java runtime?

### Reflect

- What does Conan's profile say about the compiler, and what does it not do?
