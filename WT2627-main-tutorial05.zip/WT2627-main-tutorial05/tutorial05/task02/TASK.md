## Task 02 | Is the Service Affected?

The university's security team will scan your SBOMs. Scan them first, together with the vendor library `audit` 2.3.0 in `task01/roombooking/libs/audit`.

**Decide for every finding whether the service is affected.**

1. Back each verdict with evidence from the code of the service and its libraries.
2. Record the verdicts as VEX: the next scan reports only the open findings.

### Reflect

- Which verdict changes if `audit` calls another Guava API, and which input decides?
- Through which station of the course map did each finding enter the service?
