## Task 01 | Know What You Ship

A university buys our room booking service and asks for an SBOM. The service is in `roombooking/`, with the fix from Tutorial 02.

**Produce a build SBOM of the whole project and an SBOM of `server-1.0.0-shaded.jar`.** **Compare them.**

1. Which components appear in only one of them, and why?
2. Which SBOM goes to the university?

### Reflect

- Which of [NTIA's minimum elements for an SBOM](https://www.ntia.gov/report/2021/minimum-elements-software-bill-materials-sbom) are missing in your SBOMs?
- Which SBOM do you regenerate for the next release, from which input?
