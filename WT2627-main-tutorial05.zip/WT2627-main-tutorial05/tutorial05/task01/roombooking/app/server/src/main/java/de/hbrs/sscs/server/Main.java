package de.hbrs.sscs.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import com.example.booking.rooms.Rooms;
import com.example.platform.audit.AuditLog;

/** HTTP API of the room booking service on port 8080. */
public final class Main {

    public static void main(String[] args) throws IOException {
        String buildInfo = readBuildInfo();
        Rooms rooms = new Rooms();
        AuditLog audit = new AuditLog();

        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/health", guarded(exchange -> send(exchange, 200, "ok\n")));
        server.createContext("/info", guarded(exchange -> send(exchange, 200, buildInfo)));
        server.createContext("/rooms", guarded(exchange -> send(exchange, 200, rooms.overview())));
        server.createContext("/bookings", guarded(exchange -> book(exchange, rooms, audit)));
        server.start();
        System.out.print("Room booking service listening on port 8080\n" + buildInfo);
    }

    // POST /bookings: room in the body, user in X-User
    private static void book(HttpExchange exchange, Rooms rooms, AuditLog audit) throws IOException {
        if (!"POST".equals(exchange.getRequestMethod())) {
            send(exchange, 405, "use POST\n");
            return;
        }
        String room = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8).strip();
        String user = exchange.getRequestHeaders().getFirst("X-User");
        // every attempt is audited, rejected ones included
        audit.record(user, "book", room);
        if (user == null) {
            send(exchange, 401, "missing X-User\n");
        } else if (rooms.book(room, user)) {
            send(exchange, 201, room + " booked for " + user + "\n");
        } else {
            send(exchange, 409, room + " is not available\n");
        }
    }

    // Logs a failing handler and answers 500
    private static HttpHandler guarded(HttpHandler handler) {
        return exchange -> {
            try {
                handler.handle(exchange);
            } catch (Throwable failure) {
                System.err.println("request failed: " + exchange.getRequestMethod() + " "
                        + exchange.getRequestURI());
                failure.printStackTrace();
                send(exchange, 500, "internal error\n");
            }
        };
    }

    private static void send(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(bytes);
        }
    }

    private static String readBuildInfo() throws IOException {
        try (InputStream in = Main.class.getResourceAsStream("/build.properties")) {
            return in == null ? "no build info\n" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
