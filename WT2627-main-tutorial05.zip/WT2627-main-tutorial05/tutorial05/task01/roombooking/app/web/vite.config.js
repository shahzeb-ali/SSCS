import { defineConfig } from "vite";

// The API runs on port 8080; the dev server forwards the API paths to it
export default defineConfig({
  server: {
    host: true,
    proxy: {
      "/health": "http://localhost:8080",
      "/rooms": "http://localhost:8080",
      "/bookings": "http://localhost:8080",
      "/info": "http://localhost:8080",
    },
  },
});
