// Lists the rooms and books one for the entered user
const rooms = document.querySelector("#rooms");
const result = document.querySelector("#result");

async function showRooms() {
  const response = await fetch("/rooms");
  rooms.textContent = await response.text();
}

document.querySelector("#booking").addEventListener("submit", async (event) => {
  event.preventDefault();
  const response = await fetch("/bookings", {
    method: "POST",
    headers: { "X-User": document.querySelector("#user").value },
    body: document.querySelector("#room").value,
  });
  result.textContent = `${response.status} ${await response.text()}`;
  await showRooms();
});

showRooms();
