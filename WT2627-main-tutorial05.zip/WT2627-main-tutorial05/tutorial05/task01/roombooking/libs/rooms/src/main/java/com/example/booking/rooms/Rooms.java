package com.example.booking.rooms;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;

/** The bookable rooms and who holds each one, kept in memory. */
public final class Rooms {

    private static final List<String> ALL =
            Stream.of("A101", "B204", "C116").collect(ImmutableList.toImmutableList());

    private final Map<String, String> holders = new ConcurrentHashMap<>();

    /** One line per room with its holder, or "free". */
    public String overview() {
        StringBuilder lines = new StringBuilder();
        for (String room : ALL) {
            String holder = MoreObjects.firstNonNull(holders.get(room), "free");
            lines.append(room).append(' ').append(holder).append('\n');
        }
        return lines.toString();
    }

    /** Books a room for a user; false if the room does not exist or is already booked. */
    public boolean book(String room, String user) {
        return ALL.contains(room) && holders.putIfAbsent(room, user) == null;
    }
}
