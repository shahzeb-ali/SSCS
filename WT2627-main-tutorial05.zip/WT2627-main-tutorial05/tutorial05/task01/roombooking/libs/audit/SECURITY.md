# Security Statement | audit 2.3.0

audit 2.3.0 depends on Guava 20.0. Dependency scanners report CVE-2018-10237, CVE-2020-8908 and
CVE-2023-2976 for this Guava version. audit is not affected: it calls none of the APIs these CVEs
concern. We have no plans to move to a newer Guava version.
