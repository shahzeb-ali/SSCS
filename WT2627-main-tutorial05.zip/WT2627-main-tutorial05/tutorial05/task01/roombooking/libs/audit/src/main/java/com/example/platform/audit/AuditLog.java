package com.example.platform.audit;

import java.time.Instant;

import com.google.common.base.Objects;

/** Audit trail shared by all services: one line per recorded action. */
public final class AuditLog {

    /** Records who did what to which resource; a caller without identity is recorded as anonymous. */
    public void record(String user, String action, String resource) {
        String actor = Objects.firstNonNull(user, "anonymous");
        System.out.println("AUDIT " + Instant.now() + " user=" + actor
                + " action=" + action + " resource=" + resource);
    }
}
