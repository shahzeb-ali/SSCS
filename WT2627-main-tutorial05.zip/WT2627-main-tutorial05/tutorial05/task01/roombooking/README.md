# Room Booking Service with the Fix of Tutorial 02

The room booking service of `tutorial02/task02` with the fix of Tutorial 02, Task 03: the module `app/audit-shaded` packs `audit` 2.3.0 together with a private copy of its Guava 20.0 under the package `com.example.platform.audit.shaded.guava`, and `app/server` depends on `audit-shaded` instead of `audit`. Bookings work again; `rooms` keeps running on Guava 33.7.2-jre.

- `libs/audit`, `libs/rooms`: the two vendor libraries, unchanged
- `app/audit-shaded`: `audit` with its relocated Guava
- `app/server`: HTTP API on port 8080, packaged as one executable uber-jar
- `app/web`: web frontend, unchanged

## Build and run

Inside the dev container of `tutorial05/`:

```bash
cd tutorial05/task01/roombooking
mvn -B -f libs/audit install
mvn -B -f libs/rooms install
cd app
mvn -B install
java -jar server/target/server-1.0.0-shaded.jar
```

```bash
curl -i -X POST -H "X-User: alice" -d "A101" http://localhost:8080/bookings   # 201
```
